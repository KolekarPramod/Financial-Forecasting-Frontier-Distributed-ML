# job3_conversion_rate_by_month.py
from mrjob.job import MRJob
import csv

class Job3ConversionRateByMonth(MRJob):
    
    def mapper(self, _, line):
        try:
            row = next(csv.reader([line]))
            if row[0] == 'age':
                return
            month = row[10].lower()
            y = row[-1].strip().lower()
            is_yes = 1 if y == 'yes' else 0
            yield month, (1, is_yes)
        except Exception:
            pass

    def reducer(self, month, values):
        total_contacts = 0
        total_yes = 0
        for cnt, is_conversion in values:
            total_contacts += cnt
            total_yes += is_conversion
        if total_contacts > 0:
            conversion_rate = (total_yes / total_contacts) * 100
            yield month, f"{conversion_rate:.2f}%"

if __name__ == '__main__':
    Job3ConversionRateByMonth.run()
