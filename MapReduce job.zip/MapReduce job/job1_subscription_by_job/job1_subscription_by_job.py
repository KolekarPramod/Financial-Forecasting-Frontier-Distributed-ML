# job1_subscription_by_job.py
from mrjob.job import MRJob
import csv

class Job1SubscriptionByJob(MRJob):
    def mapper(self, _, line):
        try:
            row = next(csv.reader([line]))
            if row[0] == 'age':  # header check
                return
            job = row[1]
            y = row[-1].strip().lower()
            if y == 'yes':
                yield job, 1
        except Exception as e:
            pass  # ignore badly formatted lines

    def reducer(self, job, counts):
        yield job, sum(counts)

if __name__ == '__main__':
    Job1SubscriptionByJob.run()
