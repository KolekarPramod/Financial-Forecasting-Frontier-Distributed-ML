# job2_avg_balance_by_education.py
from mrjob.job import MRJob
import csv

class Job2AvgBalanceByEducation(MRJob):
    
    def mapper(self, _, line):
        try:
            row = next(csv.reader([line]))
            if row[0] == 'age':  # Skip header
                return
            education = row[3]
            balance = int(row[5])
            yield education, (balance, 1)
        except Exception:
            pass  # skip any bad rows
    
    def reducer(self, education, values):
        total_balance = 0
        count = 0
        for bal, cnt in values:
            total_balance += bal
            count += cnt
        if count > 0:
            avg = total_balance / count
            yield education, round(avg, 2)

if __name__ == '__main__':
    Job2AvgBalanceByEducation.run()
